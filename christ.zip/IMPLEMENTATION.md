# Fix Cycles - Complete Corrected Implementation

## Executive Summary

This document contains the complete corrected implementation for the fix cycles PR. The junior developer's attempt had several critical regressions that need to be addressed before merge.

## Critical Issue #1: OrgRole Import REGRESSION

**Location**: `packages/api-framework/src/index.ts` line 63

**Current (WRONG)**:
```typescript
import type { OrgRole } from "../../types/src/rbac";
```

**Corrected**:
```typescript
import type { OrgRole } from "@fresh-schedules/types";
```

**Why the relative import breaks**: After `tsup` builds the package to `dist/`, the relative path `../../types/src/rbac` no longer resolves correctly because the built files are in a different directory structure.

---

## Critical Issue #2: Missing TypeScript Project References

The junior dev partially consolidated tsconfigs but didn't enable **composite mode** or set up proper **project references**, which are required for the package alias imports to work correctly.

### Fix: `tsconfig.base.json`

Add `packages/api-framework` to references (it was missing):

```json
{
  "files": [],
  "references": [
    { "path": "./packages/types" },
    { "path": "./packages/api-framework" },
    { "path": "./packages/ui" },
    { "path": "./packages/config" },
    { "path": "./packages/rules-tests" },
    { "path": "./apps/web" },
    { "path": "./functions" }
  ],
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2023", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "allowJs": false,
    "checkJs": false,
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "incremental": true,
    "skipLibCheck": true,
    "types": ["node"],
    "baseUrl": ".",
    "paths": {
      "@fresh-schedules/types": ["packages/types/src/index.ts"],
      "@fresh-schedules/api-framework": ["packages/api-framework/src/index.ts"],
      "@fresh-schedules/api-framework/testing": ["packages/api-framework/src/testing.ts"],
      "@types/*": ["packages/types/src/*"],
      "@ui/*": ["packages/ui/src/*"],
      "@config/*": ["packages/config/src/*"]
    }
  }
}
```

### Fix: `packages/types/tsconfig.json`

Add `composite: true` for project references:

```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "composite": true,
    "declaration": true,
    "declarationMap": true,
    "outDir": "dist",
    "rootDir": "src",
    "skipLibCheck": true,
    "types": ["node"],
    "typeRoots": ["../../node_modules/@types"]
  },
  "include": ["src"],
  "exclude": ["node_modules", "dist"]
}
```

### Fix: `packages/api-framework/tsconfig.json`

Add `composite: true` AND a reference to the `types` package:

```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "composite": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "outDir": "./dist",
    "rootDir": "src",

    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "lib": ["ES2022"],

    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "isolatedModules": true,

    "types": ["node"],
    "typeRoots": ["../../node_modules/@types", "./node_modules/@types"],
    
    "paths": {
      "@fresh-schedules/types": ["../types/src/index.ts"]
    }
  },
  "references": [
    { "path": "../types" }
  ],
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "**/*.test.ts"]
}
```

---

## Critical Issue #3: tsup.config.ts Missing Externals

**Location**: `packages/api-framework/tsup.config.ts`

**Current**:
```typescript
external: ["next", "firebase-admin", "zod"],
```

**Corrected**:
```typescript
external: [
  "@fresh-schedules/types",  // NEW - prevents bundling, resolved via package.json
  "next",
  "firebase-admin", 
  "zod",
  "ioredis",                 // NEW - server-only, prevents Edge Runtime issues
],
```

---

## Critical Issue #4: Rate Limiting Static Import

**Location**: `apps/web/src/lib/api/rate-limit.ts`

The current file has a static import at the top:
```typescript
import Redis from "ioredis";
```

This breaks Edge Runtime because `ioredis` uses Node.js APIs.

### Solution A: Rename to `.server.ts` (Recommended)

Rename the file to `rate-limit.server.ts` and add:

```typescript
import "server-only";
import Redis from "ioredis";
// ... rest of file unchanged
```

This tells Next.js to never bundle this file for Edge Runtime.

### Solution B: Dynamic Import (Less Preferred)

If you must keep the file as `.ts`, use proper dynamic imports:

```typescript
// Don't import at top level
// import Redis from "ioredis";

// Instead, lazy load inside the function:
async function getRedisClient() {
  if (typeof window !== 'undefined') {
    throw new Error('Redis client cannot be used in browser');
  }
  const { default: Redis } = await import('ioredis');
  return new Redis(env.REDIS_URL as string, {
    maxRetriesPerRequest: 1,
    enableReadyCheck: true,
  });
}
```

**Note**: The junior dev's `new Function()` approach is blocked by CSP and should not be used.

---

## Critical Issue #5: OrgRole Import Fix in index.ts

**File**: `packages/api-framework/src/index.ts`

Replace line 63:
```typescript
// WRONG - relative path breaks after build
import type { OrgRole } from "../../types/src/rbac";
```

With:
```typescript
// CORRECT - resolved via tsconfig paths and external in tsup
import type { OrgRole } from "@fresh-schedules/types";
```

---

## CI Verification Additions

Add these checks to `.github/workflows/ci.yml`:

```yaml
  verify-imports:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Check for relative cross-package imports
        run: |
          # Fail if api-framework imports from types using relative paths
          if grep -r "from ['\"]\.\.\/\.\.\/types" packages/api-framework/src/; then
            echo "ERROR: Found relative imports to types package. Use @fresh-schedules/types instead."
            exit 1
          fi
          
      - name: Check for ignoreBuildErrors
        run: |
          if grep -r "ignoreBuildErrors.*true" apps/web/next.config.mjs; then
            echo "ERROR: ignoreBuildErrors must be false"
            exit 1
          fi

  build-order:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v2
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'
          
      - name: Install dependencies
        run: pnpm install --frozen-lockfile
        
      - name: Build packages in dependency order
        run: |
          # Build types first (no dependencies)
          pnpm --filter @fresh-schedules/types build
          
          # Build api-framework (depends on types)
          pnpm --filter @fresh-schedules/api-framework build
          
          # Build web app (depends on both)
          pnpm --filter @apps/web build
```

---

## Verification Checklist

Run these commands after applying fixes:

```bash
# 1. Clean all caches
rm -rf node_modules/.cache packages/**/dist apps/web/.next

# 2. Fresh install
pnpm install

# 3. Build with project references
pnpm tsc --build

# 4. Run all checks
pnpm typecheck
pnpm lint
pnpm test:unit
pnpm test:integration
pnpm build

# 5. Verify the fix worked
grep -r "from ['\"]\.\.\/\.\.\/types" packages/api-framework/src/
# Should return NO results
```

---

## Documentation Corrections

The junior dev's `FIX_CYCLES_PREVENTION.md` contains inaccuracies. Correct:

1. **Claim**: "OrgRole now uses package alias"  
   **Reality**: It was reverted to relative import and still needs fixing

2. **Missing**: Explanation of TypeScript project references architecture

3. **Missing**: The `server-only` pattern for Edge Runtime compatibility

---

## Summary of Required Changes

| File | Change |
|------|--------|
| `tsconfig.base.json` | Add api-framework to references |
| `packages/types/tsconfig.json` | Add `composite: true` |
| `packages/api-framework/tsconfig.json` | Add `composite: true` + reference to types |
| `packages/api-framework/tsup.config.ts` | Add `@fresh-schedules/types` and `ioredis` to externals |
| `packages/api-framework/src/index.ts` | Change OrgRole import to use package alias |
| `apps/web/src/lib/api/rate-limit.ts` | Rename to `.server.ts` + add `import "server-only"` |
| `.github/workflows/ci.yml` | Add import verification checks |

## Files Created

The corrected versions of these files are available in:
- `/home/claude/fix-cycles-corrected/tsconfig.base.json`
- `/home/claude/fix-cycles-corrected/packages/types/tsconfig.json`
- `/home/claude/fix-cycles-corrected/packages/api-framework/tsconfig.json`
- `/home/claude/fix-cycles-corrected/packages/api-framework/tsup.config.ts`
